
public class TesteReatangulo {

	public static void main(String[] args) {
		
		Retangulo ret1 = new Retangulo();
		Retangulo ret2 = new Retangulo();
		
		ret1.setComprimento(4);
		ret1.setLargura(2);
		
		ret2.setComprimento(7.3);
		ret2.setLargura(3.5);
		
		System.out.printf("\n1°Perim.: %.2f | 1°Area: %.2f",
				ret1.getPerimetro(), ret1.getArea());
		System.out.printf("\n2°Perim.: %.2f | 2°Area: %.2f",
				ret2.getPerimetro(), ret2.getArea());
		
	}

}
