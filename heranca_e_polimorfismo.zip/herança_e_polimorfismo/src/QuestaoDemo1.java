import java.util.Scanner;

public class QuestaoDemo1 {
   public static void main(String[] args) {
      Scanner in = new Scanner(System.in);

      QuestaoBasica questao = new QuestaoBasica();
      questao.setPergunta("Qual a capital do Brasil?");
      questao.setResposta("Brasilia");      

      questao.perguntar();
      System.out.print("Sua resposta: ");
      String resposta = in.nextLine();
      System.out.println(questao.verificarResposta(resposta));
   }
}