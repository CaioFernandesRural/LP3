package eleicoes;

class Candidato {
    String nome;
    int numVotos;

    Candidato(String nome, int numVotos) {
       this.nome = nome;
       this.numVotos = numVotos;
    }
} 
