package eleicoes;

class ContagemVotos {
    int validos;
    int invalidos;

    ContagemVotos(int validos, int invalidos) {
       this.validos = validos;
       this.invalidos = invalidos;
    }
} 
